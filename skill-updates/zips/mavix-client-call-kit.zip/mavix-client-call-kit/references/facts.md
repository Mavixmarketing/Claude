# Mavix facts — the source of truth

Nothing may contradict this file. If something is not here it is a blank marked `[ASK FARHAN]`, never a guess.

## The business

**Farhan** (Mohd Farhan), founder, **Mavix Marketing**. Based in **Dubai**, a team of **30+ people**, working since 2019. Never say "small team", and never "Farhan runs your account himself": every account has one named account manager, and Farhan takes the first call and joins every monthly review.

**Three services only: search, paid ads, email.** Nothing else.

Clients mostly USA and UK.

### The company story (the same words in all three skills)

Facts from mavixmarketing.com (about page and home page, read 23 October 2026) plus Farhan's
confirmation of Dubai and 30+ people. Shorten it to fit; never add to it.

> Mavix Marketing is based in Dubai, with a team of 30+ people across Dubai, Los Angeles and
> New Delhi. Everyone who does the work is employed by Mavix, not subcontracted. We do SEO, paid
> ads and email, and have done since 2019. On search we are not a traditional SEO agency: we get
> businesses found on Google, Google Maps, and in AI answers such as Google's AI Overviews and
> ChatGPT. Every account has one named account manager for the day to day. Our founder, Mohd
> Farhan, takes the first call with every new client and joins every monthly review. Reports
> lead with enquiries, and every number comes from the client's own accounts.

Not in the story on purpose: a client count (the website says 150+ on one page and 200+ on
another, so it is not used), awards, and anything else the website does not say.

## The call

30 minutes · Google Meet · booked via cal.com · **not recorded, never mention recording** · one call · price said out loud.

## The intro — say it the same way every time

> Let me give you a quick background on me. I'm Farhan, and I built Mavix Marketing from the ground up.
>
> Before I started the agency I spent my time running the daily growth pipelines and the technical backends for other people's businesses. And during that time I watched a lot of hard-working founders get completely burned by agencies. Locked into long contracts by people hiding behind vanity metrics, draining budgets, delivering no actual sales.
>
> I got sick of watching it, so I built Mavix to be the opposite.
>
> We're headquartered in Dubai, team of just over thirty, and we work strictly on performance. We offer three services and three only — search, paid ads, and email. Nothing more, nothing less.
>
> The reason we refuse to do anything else is simple. An agency that does fifteen things is great at none of them. Those three are the only proven ways to catch people who are already looking to buy and turn them into money. If a service doesn't put cash back in your pocket, we don't touch it.
>
> And the reason we don't tie anyone into a contract is just as simple. If we get you what you want, you won't want to leave. We believe in the work, so we don't need to trap you.
>
**The last paragraph changes with the service and the package. Everything above it never changes.**

**On an SEO call, Growth or Premium:**

> I want founders sleeping properly instead of lying awake worrying about their marketing. That's why the guarantee is in writing. Before you start, we agree a 90-day target together, in writing. If I miss it, you get back everything you paid, plus a thousand-dollar cheque out of my own pocket. The financial risk sits on my shoulders, not yours.

**On an SEO call where Starter is the likely package** — Starter carries no guarantee, so promising one in minute three and withdrawing it in minute twenty-five is a lie you tell yourself:

> I want founders sleeping properly instead of lying awake worrying about their marketing. That's why there's no long contract. The agreement has no time limit and the only side it ties is mine, to deliver. No setup fee, and every account stays in your name. On the bigger packages there's a written money-back guarantee on top, and I'll walk you through exactly how that works when we get to the numbers.

**On an ads call** — the written guarantee names traffic, rankings and visitors, which is search work. Never say it on an ads call:

> I want founders sleeping properly instead of lying awake worrying about their marketing. That's why there's no contract, no setup fee, and thirty days' notice. Your ad budget stays on your own card, going straight to Google or Meta — it never comes through me. And every account, every pixel, every bit of the history stays in your name. If you walk, you walk with all of it. The risk of me being wrong sits on my shoulders, not yours.

## SEO pricing: it depends on the campaign

The emailed SEO audit carries no price. Prices are said on the call, shown on the review PDF's
pricing page, and sent after a "yes". **Which prices apply depends on the SalesBlink campaign
the prospect came from.** Read it from the thread or Farhan's notes. If it is not clear, ask
Farhan before building: `[ASK FARHAN] which campaign`. Never mix the two sets.

| Campaign | Starter | Growth (recommended) | Premium |
|---|---|---|---|
| **USA/Canada** and **Aus/UK/NZ/Sing** | **$349/mo** | **$549/mo** | **$1,649/mo** |
| **AI Written** | **$999/mo** | **$1,349/mo** | **$1,999/mo** |

**If a price was already quoted to this prospect, honour it.** Use the quoted number on the
call, in the script and on the review PDF, even if the table above has changed since.

What is in each package (the same on every campaign):

| Package | What's in it |
|---|---|
| **Starter** | Keyword and competitor research · 2 blogs/month · Pinterest 8 · directories 12 · social bookmarking 8 · profile creation 8 · multi-link 16 · Q&A 8 · monthly report · **no money-back guarantee** |
| **Growth** ⭐ recommended | Everything in Starter, plus 3-4 blogs/month · 2 guest posts · PPT/PDF 8 · articles 8 · infographics 8 · 1 PR submission · GMB optimisation 2 · **90-day money-back guarantee** · **price locked for life** |
| **Premium** | Everything in Growth, plus 8+ blogs · 8+ guest posts · full page-by-page audit and fixes · site speed and broken links · competitor gap analysis · priority support · **90-day money-back guarantee** |

Starter has **no money-back guarantee** on any campaign. Growth and Premium carry the same
90-day guarantee on every campaign. There is no "was" price; never quote one.

**Lead with Growth.** The price lock is a real reason to decide today — it does not expire tonight, it just stops applying when rates go up.

Say prices out loud as: "three-forty-nine", "five-forty-nine", "sixteen-forty-nine" a month
(USA/Canada, Aus/UK/NZ/Sing), or "nine-ninety-nine", "thirteen-forty-nine",
"nineteen-ninety-nine" a month (AI Written).

## Ads pricing

Month 1 **$249** · Month 2 **$349** · Month 3 onwards **$449** flat.

Ad budget is always the client's, on their card, direct to the platform. Never through Mavix. Say it every time.

**Why it starts low, in Farhan's own words:**
> It starts low on purpose. Running ads needs real money in the ad budget, and it takes time for the platform to settle. Keeping my fee low for the first two months means my fee isn't the thing holding you back.

**Why month one isn't free:**
> Because it isn't free for me. Month one is setup, tracking, research and building the campaigns, plus the software costs on my end. I'd rather charge a low fee and do the work than call it free and cut corners.

## Floors

**SEO: the floor is the Starter price for the prospect's campaign** ($349 on USA/Canada and Aus/UK/NZ/Sing, $999 on AI Written, or a lower price already quoted to them) until Farhan sets a separate number. **Ads $200.** Below that, walk. Two moves only when money is the blocker: move down a package, or walk politely. **Never invent a number on a call.**

## Guarantee

**Growth and Premium only.** Before the work starts, we agree a 90-day target with the client in writing (for example, a set of agreed searches on page one of Google). If we miss it, the client gets back everything they paid, plus $1,000. **Starter has none — never imply otherwise, including in the intro.** Say "the target we agree in writing", never a target nobody has agreed yet.

**This guarantee is for search work only.** It is about search results. It has no meaning on an ads deal and must never appear in an ads document or an ads call.

## The ads offer — there is no ads guarantee

**Settled. Do not mark it `[ASK FARHAN]` and do not invent one.** On an ads deal there is no money-back guarantee, no promised return, no lead count. What replaces it is the pricing itself, plus the terms.

**The offer, said as one thing:**

> There's no guarantee on ads, and anyone who gives you one is guessing. What I'll do instead is start my fee low while the account is still proving itself — two-forty-nine the first month, three-forty-nine the second, four-forty-nine from there. Your ad budget stays on your own card going straight to Google or Meta, it never touches me. No setup fee, no contract, thirty days' notice, and every account, every pixel and all the history stays in your name. If you walk, you walk with all of it.

**Why this is stronger than a guarantee, and worth saying out loud:** a guarantee on ads would be a promise about an auction nobody controls. The low opening fee is a real cost he carries, in advance, before the account has proved anything. That is the risk actually moving to his side. Plus a **$1,000 penalty cheque** from Farhan personally.

**Never say "90-day full refund."** It contradicts the package sheet. The ads proposal skill currently prints that line — it is wrong there too.

**There is no ads guarantee, by design.** See "The ads offer" above — the low opening fee and the terms are what stand in its place. Never print a guarantee on an ads document.

## Terms

**Search:** no setup fee · no long contract: the agreement has no time limit and only ties Mavix, to deliver · client keeps every account on exit.

**Ads:** the ads terms in `ads-track.md` are unchanged in this update (they still say thirty days' notice). Ask Farhan whether the no-time-limit wording applies to ads too before changing them. $1,000 Google ad credit on qualifying spend (ads only).

## AI search: how Mavix describes itself on a search call

Mavix is not a traditional SEO agency. It gets businesses found on Google, Google Maps, Google's AI Overviews and AI Mode, and AI assistants like ChatGPT.

**The only two outside facts allowed. Say the source every time. No other AI numbers:**

- Google says AI Overviews reach over 2 billion people a month (Alphabet, July 2025).
- A Pew Research study (July 2025) found people clicked a normal search result on 8% of searches that showed an AI summary, against 15% without one.

**What we actually do for it, and nothing else:** answer-style pages for the questions customers ask, structured data, the Google Business Profile and reviews, mentions and links on trusted sites, and technical fixes.

**Never promise they will appear in an AI answer.** If asked: *"Nobody can promise that, Google included. What I can do is make you the clearest, best-sourced answer for what you sell, which is what those tools pull from."*

## The 15-minute walkthrough

Anyone who got an audit and has questions gets offered a 15-minute walkthrough: https://cal.id/mavixmarketing/strategy-call. It walks through their audit, answers their questions, and ends with one plan and one price.

## Capacity

**10 new clients a month.** Only ever say the real current number.

## Closing

**No contract signed on the call.** Ask for **$50-$100** to hold the slot, onboarding link the same day, rest that week. **Ask once.** If they hesitate: *"No problem — onboarding link goes over today, sort the payment when you're ready this week."*

## Case studies

The real case studies from mavixmarketing.com/case-studies, named exactly the way the website names them, with the website's numbers, timeframe and URL. **Never name a client the website does not name** — one exception: **Brother Filtration is cleared as a named reference**, live Search Console and Analytics can be shown.

**`references/case-library.md` decides which three to pick.** It holds the full roster, the industry lookup, the country rule and the fallback. Do not pick from memory and do not pick from this page.

What this page fixes, and `case-library.md` may not contradict: the website's names only, never an invented one and never a client the website does not name; the website's figures and the dashboards are the only ads and search figures that exist; and the service decides the list before the industry does.

Never put an ads case study in an SEO kit or the reverse, whatever the industry match looks like.

## Never say

Page one · guaranteed rankings · guaranteed leads · a specific return · "we're Google partners" · "this price ends tonight" · invented slot scarcity · a client name the website does not use · an invented client name · any number not on the screen · anything critical about their staff

## Facts he can quote

- Google: *"No one can guarantee a #1 ranking on Google."* — Google Search Central
- Google Ads: wait for around 100 recorded sales or enquiries before judging what each one costs
- Meta: roughly 50 events in 7 days to leave the learning phase

Do not use the "Google says SEO takes four months to a year" line. It is not on Google's current page.
